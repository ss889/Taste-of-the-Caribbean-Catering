import { StyleSheet, Text, View } from 'react-native'
import { Slot, SplashScreen, Stack, useSegments, useRouter } from 'expo-router'
import { useFonts } from 'expo-font'
import { useEffect } from 'react'
import { AuthContextProvider, useAuth } from '@/Contexts/AuthContext';
import { StatusBar } from 'expo-status-bar';

SplashScreen.preventAutoHideAsync();

const MainLayout = () =>{
  const { isAuthenticated, checkEmailVerification } = useAuth();
  const segments = useSegments();
  const router = useRouter();
  

  useEffect(()=>{
    const handleAuthState = async () =>{
      if(typeof isAuthenticated=='undefined') return;
      const inApp = segments[0] == '(tabs)';
      const emailVerified = await checkEmailVerification();
      router.replace('../home');
      // if(!emailVerified && isAuthenticated){
      //   router.replace('../verify-email');
      //   return;
      // }
      // if(isAuthenticated && !inApp){
      //   router.replace('../home');
      // }else{
      //   router.replace('/');
      // }
    };

    handleAuthState();
    SplashScreen.hideAsync();

  }, [isAuthenticated])

  return <Slot />
}


export default function RootLayout() {
  return (
    <AuthContextProvider>
      <MainLayout />
    </AuthContextProvider>

    // <Stack>
    //   <Stack.Screen name="index" options={{ headerShown:
    //     false }}/>
    //   <Stack.Screen name="(tabs)" options={{ headerShown:
    //     false }}/>

    // </Stack>
  )
}

