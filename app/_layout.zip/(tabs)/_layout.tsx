import { View, Text, Image } from 'react-native'
import { Tabs, Redirect } from 'expo-router'

import { icons } from '../../constants'
import { Octicons } from '@expo/vector-icons'
import { MaterialIcons, MaterialCommunityIcons } from '@expo/vector-icons'

const TabIcon = ({ icon, color, name, focused }) => {
    return (
        <View className="items-center justify-center gap-2">
            <Image 
                source={icon}
                resizeMode="contain"
                tintColor={color}
                className='w-8 h-8'
            />
        </View>
    )
}

const TabsLayout = () => {
  return (
    <>
        <Tabs
            screenOptions={{
                tabBarShowLabel: true,
                tabBarActiveTintColor: "#00CC99",
            }}
        >
            <Tabs.Screen
                name="home"
                options={{
                    title: 'Home',
                    headerShown: false,
                    tabBarIcon: ({ color, focused }) => (

                        <MaterialIcons name="home" color={color} size={30}/>


                        // <TabIcon 
                        //     icon={icons.home}
                        //     color={color}
                        //     name="Home"
                        //     focused={focused}
                        // />
                       
                    )
                }}
            />

            <Tabs.Screen
                name="menu"
                options={{
                    title: 'Menu',
                    headerShown: false,
                    tabBarIcon: ({ color, focused }) => (

                        <MaterialIcons name="menu-book" color={color} size={30} />


                        // <TabIcon
                        //     icon={icons.menu}
                        //     color={color}
                        //     name="Menu"
                        //     focused={focused}
                        // />
                       
                    )
                }}
            />

            <Tabs.Screen
                name="cart"
                options={{
                    title: 'Cart',
                    headerShown: false,
                    tabBarIcon: ({ color, focused }) => (

                        <MaterialIcons name="shopping-cart" color={color} size={30} />

                       
                    )
                }}
            />
            <Tabs.Screen
                name="profile"
                options={{
                    title: 'Profile',
                    headerShown: false,
                    tabBarIcon: ({ color, focused }) => (

                        <MaterialCommunityIcons name="account" color={color} size={30} />

                       
                    )
                }}
            />


             
        </Tabs>
    </>
  )
}

export default TabsLayout