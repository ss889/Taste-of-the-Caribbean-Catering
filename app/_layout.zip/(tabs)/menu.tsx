import { View, Text } from 'react-native'
import React from 'react'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Image } from 'react-native-elements'
import MenuCategories from '@/components/MenuCategories'
import { icons } from '@/constants'

const Menu = () => {
  return (
    <SafeAreaView className="flex-1 bg-white">
      <View className="flex-1 items-center justify-start pt-10 space-y-8">
        <Image 
          source={icons.logo} 
          className="w-24 h-24" 
        />
        <Text className="text-2xl text-gray-800">Menu</Text>
        <View className='w-full'>
          <MenuCategories/>
        </View>

      </View>
    </SafeAreaView>
  )
}

export default Menu